package reports;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import utilities.ExecutionSummary;

public final class ExcelDashboardWriter {

    private ExcelDashboardWriter() {

    }

    public static XSSFSheet buildDashboard(XSSFWorkbook workbook,
                                           XSSFSheet sheet,
                                           ExecutionSummary summary) {

        // Get current sheet index
        int sheetIndex = workbook.getSheetIndex(sheet);

        // Remove old sheet
        workbook.removeSheetAt(sheetIndex);

        // Create fresh sheet
        sheet = workbook.createSheet("Execution Summary");

        // Keep same sheet position
        workbook.setSheetOrder("Execution Summary", sheetIndex);

        // Dashboard Title
        createTitle(workbook, sheet);

        // Execution Information
        createSection(workbook, sheet, 2, "Execution Information");

        ExcelExecutionInfoWriter.write(
                workbook,
                sheet,
                summary,
                3);

        // Execution Statistics
        createSection(workbook, sheet, 11, "Execution Statistics");

        ExcelStatisticsWriter.write(
                workbook,
                sheet,
                summary,
                12);

        sheet.autoSizeColumn(0);
        sheet.autoSizeColumn(1);

        sheet.createFreezePane(0, 2);

        return sheet;
    }

    private static void createTitle(XSSFWorkbook workbook,
                                    XSSFSheet sheet) {

        Row row = sheet.createRow(0);
        row.setHeightInPoints(25);

        Cell cell = row.createCell(0);

        cell.setCellValue("AUTOMATION EXECUTION DASHBOARD");

        CellStyle style = ExcelStyle.createTitleStyle(workbook);

        cell.setCellStyle(style);

        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 3));
    }

    private static void createSection(XSSFWorkbook workbook,
                                      XSSFSheet sheet,
                                      int rowNumber,
                                      String title) {

        Row row = sheet.createRow(rowNumber);

        Cell cell = row.createCell(0);

        cell.setCellValue(title);

        cell.setCellStyle(ExcelStyle.createSectionStyle(workbook));

        sheet.addMergedRegion(
                new CellRangeAddress(rowNumber, rowNumber, 0, 1));
    }
}